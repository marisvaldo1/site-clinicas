const estadosComClinicas = {
  "AC": false, "AL": false, "AP": false, "AM": false, "BA": true,
  "CE": false, "DF": false, "ES": false, "GO": true, "MA": false,
  "MT": false, "MS": false, "MG": false, "PA": false, "PB": false,
  "PR": false, "PE": false, "PI": false, "RJ": true, "RN": false,
  "RS": false, "RO": false, "RR": false, "SC": false, "SP": true,
  "SE": false, "TO": false
};

function carregarMapa() {
  fetch('imagens/mapa_brasil.svg')
    .then(response => response.text())
    .then(svg => {
      document.getElementById('mapaBrasil').innerHTML = svg;
      adicionarInteratividade();
    })
    .catch(error => console.error('Erro ao carregar o mapa:', error));
}

function adicionarInteratividade() {
  const tooltip = document.getElementById('tooltip');
  document.querySelectorAll('#mapaBrasil svg path').forEach(estado => {
    const uf = estado.id;
    estado.addEventListener('mousemove', e => {
      const info = estadosComClinicas[uf] ? 'Clínica cadastrada' : 'Nenhuma clínica';
      tooltip.innerText = uf + ': ' + info;
      tooltip.style.display = 'block';
      tooltip.style.top = (e.pageY + 10) + 'px';
      tooltip.style.left = (e.pageX + 10) + 'px';
    });
    estado.addEventListener('mouseleave', () => {
      tooltip.style.display = 'none';
    });
    estado.style.fill = estadosComClinicas[uf] ? '#2ecc71' : '#bdc3c7';
    estado.style.stroke = '#34495e';
    estado.style.cursor = 'pointer';
  });
}

carregarMapa();